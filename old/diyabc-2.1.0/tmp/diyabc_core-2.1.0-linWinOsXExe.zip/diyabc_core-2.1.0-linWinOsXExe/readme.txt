##############################################################################################
These executable files are diyabc v2.1 core binaries (i.e. computational core :  without the GUI).
##############################################################################################

It's a CLI (Command Line Interface), so you must use them through a
command line terminal.
The binary can be useful for HPC cluster or to convert the reftable.bin 
produced by diyabc v2.1 into a reftable.txt file.


The general help command is :
(MS Windows example, read Note3):
diyabc_core-2.1.0-win.exe -h
(OsX or linux):
./diyabc_core-2.10-YourVersion -h



To convert the reftable.bin produced by diyabc v2.1 into a reftable.txt file :
#1 Go into your working directory which may be the DIYABC project directory.
       At minimum the chosen working directory should contain the following DIYABC files:
       the reference table "reftable.bin" (generated with DIYABC v2.1.0), the file RNG_state_0000.bin
       and the datafile "statobs.txt" (the latter including the summary statistics of the observed dataset)
#2 the reftable convertion command is:
(MS Windows example, read Note3):
diyabc_core-2.1.0-win.exe -p ./ -x
(OsX or linux):
./diyabc_core-2.10-YourVersion -p ./ -x

--------------------------------------------------------------------------------------------
Note1: for linux users, if you get a libc version error, please try the OldLinux version.
Note2: for linux users, it is highly recommended to download diyabc sources and compile 
       diyabc core by your own (read the diyabc manual cluster section)  
Note3: for MS windows OS you need to unzip the file diyabc_core-2.1.0-dll-windows.zip 
in order to put the dll files inthe same directory than the binary diyabc_core-2.1.0-win.exe.


