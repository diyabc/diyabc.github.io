#!/bin/bash
rm `find ./ -maxdepth 3 -iname "*.pyc"`
