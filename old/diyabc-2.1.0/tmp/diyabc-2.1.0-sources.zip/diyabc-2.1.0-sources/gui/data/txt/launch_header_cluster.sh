#!/bin/bash
numSimulatedDataSet={0}
numSimulatedDataSetByJob={1}
coresPerJob={2}
maxConcurrentJobs={3}
seed={4}
diyabcPath="{5}"
projectName="{6}"
dataFileName="{7}"
referenceTableHeaderName="{8}"

